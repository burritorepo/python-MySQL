from django.apps import AppConfig


class ReservabarberiaConfig(AppConfig):
    name = 'ReservaBarberia'
